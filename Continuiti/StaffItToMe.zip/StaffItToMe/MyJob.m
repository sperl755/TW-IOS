//
//  MyJob.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyJob.h"


@implementation MyJob
@synthesize status;
@synthesize checked_in_out;
@synthesize title;
@synthesize start_time;
@synthesize duration;
@synthesize rate;
@synthesize time_clock;
@synthesize notes;
@synthesize job_history;
@end

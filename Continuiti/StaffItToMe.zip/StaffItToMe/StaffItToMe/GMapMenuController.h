//
//  GMapMenuController.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Menu.h"


@interface GMapMenuController : UIViewController {
    Menu *my_map;
    
}

@end

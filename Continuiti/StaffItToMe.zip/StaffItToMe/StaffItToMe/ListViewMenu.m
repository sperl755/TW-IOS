//
//  ListViewMenu.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
#import "StaffItToMeAppDelegate.h"
#import "ListViewMenu.h"


@implementation ListViewMenu

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        table_view = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height) style:UITableViewStylePlain];
        table_view.dataSource = self;
        [table_view setDelegate:self];
        [self addSubview:table_view];
    }
    return self;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
    return [delegate.user_state_information.job_array count];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    printf("HELLO");
    StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
    delegate.user_state_information.current_job_in_array = indexPath.row;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"jumpToJobDetail" object:nil];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil];
    NSMutableString *cell_text = [[NSMutableString alloc] initWithString:[[[delegate.user_state_information job_array] objectAtIndex:indexPath.row] title]];
    [cell_text appendString:@" "];
    [cell_text appendString:[[delegate.user_state_information.job_array objectAtIndex:indexPath.row] compensation]];
    cell.textLabel.text = cell_text;
    
    NSMutableString *cell_subtitle_text = [[NSMutableString alloc] initWithString:[[[delegate.user_state_information job_array] objectAtIndex:indexPath.row] job_duration]];
    [cell_subtitle_text appendString:@", "];
    [cell_subtitle_text appendString:[[delegate.user_state_information.job_array objectAtIndex:indexPath.row] task_start_time]];
    [cell_subtitle_text appendString:@" "];
    [cell_subtitle_text appendString:[[delegate.user_state_information.job_array objectAtIndex:indexPath.row] task_start_date]];
    cell.detailTextLabel.text = cell_subtitle_text;
    return cell;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
	[table_view setDelegate:nil];
    [table_view release];
    [super dealloc];
}

@end

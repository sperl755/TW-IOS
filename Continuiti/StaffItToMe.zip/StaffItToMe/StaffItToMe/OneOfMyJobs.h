//
//  OneOfMyJobs.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JobBillingHistoryView.h"
#import "AllJobBillingHistories.h"
/*
 This class is the view of the MyJob Data model.
 It will be a view that is displayed showing information and
 allowing altering of the current MyJob Data Model that it is representing.
 This view will make up the jobs tab and there will be many of these views as these are scrolled through.
 */

@interface OneOfMyJobs : UIView
{
    UILabel *job_info;
	UILabel *job_active_billing;
	JobBillingHistoryView *active_bill_view;
	UIButton *check_in_out_btn;
	AllJobBillingHistories *all_jobs_history;
	UILabel *total_time_billed;
}
- (id)initWithFrame:(CGRect)frame andStatus:(int)status title:(NSString*)title startTime:(NSString*)start_time duration:(NSString*)duration rate:(NSString*)rate checkedInOrOut:(NSString*)checked_in_or_out timeClock:(NSString*)time_clock notes:(NSString*)notes;

@end

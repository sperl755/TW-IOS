//
//  JobDetailScreen.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface JobDetailScreen : UIViewController 
{
    NSUInteger array_position;
    UITextView *description_txt;
    UIButton *apply_btn;
    UIButton *discuss_btn;
}

@end

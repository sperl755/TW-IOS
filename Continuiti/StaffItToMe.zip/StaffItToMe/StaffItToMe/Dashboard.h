//
//  Dashboard.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Menu.h"


@interface Dashboard : UIView {
    UIImageView *logo_message;
    UIButton *home_btn;
    UIButton *find_work_btn;
    UIButton *my_jobs_btn;
    UIButton *im_available_btn;
    UIButton *inbox_btn;
    
}

@end

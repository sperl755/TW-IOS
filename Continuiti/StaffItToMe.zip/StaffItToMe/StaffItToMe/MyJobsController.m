    //
//  MyJobsController.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyJobsController.h"


@implementation MyJobsController

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	my_array_of_jobs = [[NSMutableArray alloc] initWithCapacity:11];
	top_arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"TopArrow"]];
	top_arrow.frame = CGRectMake(0, 0, 320, 30);
	top_arrow.hidden = YES;
	[self.view addSubview:top_arrow];
	
	bottom_arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BottomArrow"]];
	bottom_arrow.frame = CGRectMake(0, 420, 320, 30);
	bottom_arrow.hidden = NO;
	[self.view addSubview:bottom_arrow];
	for (int i = 0; i < 4; i++)
	{
		OneOfMyJobs *my_job_test_view2 = [[OneOfMyJobs alloc] initWithFrame:CGRectMake(50, (i*480), 200, 480) andStatus:3 title:@"This is the title" startTime:@"asdfasdf" duration:@"asdfasdf" rate:@"asdfasdf" checkedInOrOut:@"asdfasdf" timeClock:@"4asdfsdfsd" notes:@"Wasup"];
		[self.view addSubview:my_job_test_view2];
		[my_array_of_jobs addObject:my_job_test_view2];
		[my_job_test_view2 release];
	}
	current_job = 0;
	[super viewDidLoad];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *the_touch = [touches anyObject];
	CGPoint location = [the_touch locationInView:self.view];
	if (location.y > 400)
	{
		if (current_job >= my_array_of_jobs.count-1)
		{
			return;
		}
		top_arrow.hidden = NO;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:1];
		[UIView setAnimationRepeatCount:0];
		for (int i = 0; i < my_array_of_jobs.count; i++)
		{
			[[my_array_of_jobs objectAtIndex:i] setFrame:CGRectMake(0, [[my_array_of_jobs objectAtIndex:i] frame].origin.y - 480, 320, 480)];
		}
		[UIView commitAnimations];
		current_job++;
		if (current_job >= my_array_of_jobs.count-1)
		{
			bottom_arrow.hidden = YES;
		}
	}
	else if (location.y < 20)
	{
		if (current_job == 0)
		{
			return;
		}
		bottom_arrow.hidden = NO;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDuration:1];
		[UIView setAnimationRepeatCount:0];
		for (int i = 0; i < my_array_of_jobs.count; i++)
		{
			[[my_array_of_jobs objectAtIndex:i] setFrame:CGRectMake(0, [[my_array_of_jobs objectAtIndex:i] frame].origin.y + 480, 320, 480)];
		}
		[UIView commitAnimations];
		current_job--;
		if (current_job == 0)
		{
			top_arrow.hidden = YES;
		}
	}
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[my_array_of_jobs release];
    [super dealloc];
}


@end

//
//  Menu.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Menu.h"


@implementation Menu

#define JOB_Z_ORDER 2
#define BUTTON_Z_ORDER 9
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        local_manager = [[LocationManager alloc] init];
        local_manager.delegate = self;
        filter_screen = [[SearchFilterScreen alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
        [filter_screen setFrame:CGRectMake(0, 0, 320, 300)];
        [filter_screen setDelegate:self];
        [self addSubview:filter_screen];
		list_or_map = 0;
		
    }
    return self;
}
-(void)setupListView
{
	if (list_or_map == 0) {
	}
	else if (list_or_map == 1)
	{
		[google_map removeFromSuperview];
	}
	else if (list_or_map == 2)
	{
		[list_screen removeFromSuperview];
	}
	list_or_map = 2;
	list_screen = [[ListViewMenu alloc] initWithFrame:CGRectMake(0, 50, 320, 400)];
	[self insertSubview:list_screen atIndex:0];
}
-(void)setupGoogleMap
{
	if (list_or_map == 0) {
	}
	else if (list_or_map == 1)
	{
		[google_map removeFromSuperview];
	}
	else if (list_or_map == 2)
	{
		[list_screen removeFromSuperview];
	}
	list_or_map = 1;
    google_map = [[GoogleMapsMenu alloc] initWithFrame:CGRectMake(0, 50, 320, 400) withLocation:user_location];
	[self insertSubview:google_map atIndex:0];
}
-(void)switchView
{
	//If the List is displayed
	if (list_or_map)
	{
		[list_screen removeFromSuperView];
		list_or_map = NO;
		google_map = [[GoogleMapsMenu alloc] initWithFrame:[UIScreen mainScreen].applicationFrame withLocation:user_location];
		[self addSubview:google_map];
	}
	else
	{
		[google_map removeFromSuperview];
		list_or_map = YES;
		list_screen = [[ListViewMenu alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
		[self addSubview:list_screen];
	}

}
-(void)setUserLocation:(CLLocation*)the_location
{
    user_location = [the_location copy];
    [google_map changeCenter:user_location];
    [local_manager.manager stopUpdatingLocation];
}
-(void)viewAndApplyForJobs
{
    printf("I just got all the jobs in the world");
}
-(void)checkIntoMyJobs
{
    printf("I ran errands for ms potts!");
}


- (void)dealloc
{
    [google_map release];
    [local_manager release];
    [user_location release];
    [filter_screen release];
    [super dealloc];
}

@end

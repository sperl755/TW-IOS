//
//  GoogleMapsMenu.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GoogleMapsMenu.h"
#import "StaffItToMeAppDelegate.h"


@implementation GoogleMapsMenu

- (id)initWithFrame:(CGRect)frame withLocation:(CLLocation*)the_location
{
    self = [super initWithFrame:frame];
    if (self) {
        main_map_view = [[MKMapView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
        [self addSubview:main_map_view];
        MKCoordinateRegion beginning_region;
        beginning_region.center.latitude = the_location.coordinate.latitude;
        beginning_region.center.longitude = the_location.coordinate.longitude;
        beginning_region.span.latitudeDelta = .1;
        beginning_region.span.longitudeDelta = .1;
        [main_map_view setRegion:beginning_region animated:YES];
        main_map_view.delegate = self;
        StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
        //Fill the map with jobs that are near user.
        for (int i = 0; i < [delegate.user_state_information.job_array count]; i++) {
			//Get the location of the job
            CLLocationCoordinate2D coordinate = {[[delegate.user_state_information.job_array objectAtIndex:i] latitude], [[delegate.user_state_information.job_array objectAtIndex:i] longitude]};
			//Create an annotation for it with an id of the current position in the array that the job is in.
            AvailableJobsAnnotation *a_job = [[AvailableJobsAnnotation alloc] initWithTitle:[[delegate.user_state_information.job_array objectAtIndex:i] title] subTitle:[[delegate.user_state_information.job_array objectAtIndex:i] job_description] andCoordinate:coordinate andID:[NSString stringWithFormat:@"%d", i]];
            if (coordinate.latitude == 0) {
                [a_job release];
            }
            else {
                //add the annotation
                [main_map_view addAnnotation:a_job];
            }
        }
    }
    return self;
}
-(void)changeCenter:(CLLocation*)the_location
{
    MKCoordinateRegion beginning_region;
    beginning_region.center.latitude = the_location.coordinate.latitude;
    beginning_region.center.longitude = the_location.coordinate.longitude;
    beginning_region.span.latitudeDelta = .1;
    beginning_region.span.longitudeDelta = .1;
    [main_map_view setRegion:beginning_region animated:YES];
}
-(void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
	AvailableJobsAnnotation *annotation = view.annotation;
    StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*) [[UIApplication sharedApplication] delegate];
	delegate.user_state_information.current_job_in_array = [annotation.pin_id intValue];
	printf("%s", [annotation.pin_id UTF8String]);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"jumpToJobDetail" object:nil];
}
-(MKAnnotationView*)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    MKPinAnnotationView *pin = (MKPinAnnotationView*)[mapView dequeueReusableAnnotationViewWithIdentifier:@"Job"];
    if (!pin) {
        pin = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"Job"];
    }
    pin.pinColor = MKPinAnnotationColorRed;
    pin.animatesDrop = YES;
    pin.canShowCallout = YES;
    pin.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    return pin;
}/*
-(MKAnnotationView*)mapView:(MKMapView*)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    MKAnnotationView *view = [mapView dequeueReusableAnnotationViewWithIdentifier:@"Job1"];
    if (annotation == annotation2) {
        if (!view) {
            view = [[[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"Job1"] autorelease];
        }
        view.canShowCallout = YES;
        view.image = [UIImage imageNamed:@"FacebookPressed.png"];
        view.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        UIView *aView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 20)] autorelease];
        aView.backgroundColor = [UIColor yellowColor];
        view.leftCalloutAccessoryView = aView;
    }
    return view;
}*/

- (void)dealloc
{
    [main_map_view release];
    [super dealloc];
}

@end

//
//  ListViewMenu.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ListViewMenu : UIView <UITableViewDataSource, UITableViewDelegate>{
    UITableView *table_view;
    
}

@end

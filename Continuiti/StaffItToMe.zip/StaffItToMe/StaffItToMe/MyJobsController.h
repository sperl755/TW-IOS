//
//  MyJobsController.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/18/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OneOfMyJobs.h"

@interface MyJobsController : UIViewController {
	NSMutableArray *my_array_of_jobs;
	int current_job;
	UIImageView *top_arrow;
	UIImageView *bottom_arrow;
}

@end

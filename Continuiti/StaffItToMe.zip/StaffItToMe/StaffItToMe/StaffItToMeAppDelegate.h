//
//  StaffItToMeAppDelegate.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"
#import "SA_OAuthTwitterEngine.h"
#import "SA_OAuthTwitterController.h"
#import "FbGraph.h"
#import "SmallJobs.h"
#import "JobSearchController.h"
#import "USERINFORMATIONANDAPPSTATE.h"
#import "MyJobsController.h"
@class StaffItToMeViewController;

@interface StaffItToMeAppDelegate : NSObject <UIApplicationDelegate,FBRequestDelegate, FBSessionDelegate, SA_OAuthTwitterEngineDelegate, SA_OAuthTwitterControllerDelegate> {
    Facebook *facebook;
    SA_OAuthTwitterEngine    *twitter_engine; 
    UITabBarController *tab_bar_controller;
    UIViewController *home;
    JobSearchController *search;
    MyJobsController *jobs;
    UIViewController *inbox;
    UIViewController *about;
	BOOL got_facebook_info;
    
    UIAlertView *load_message;
}
-(void)facebookFunction;
-(BOOL)cellularConnected;
-(void)connectionFunction;
-(void)goToMainApp;
-(void)twitterLogin;
-(BOOL)wifiConnected;
-(BOOL)networkConnected;
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet StaffItToMeViewController *viewController;
@property (nonatomic, assign) USERINFORMATIONANDAPPSTATE *user_state_information;

@end

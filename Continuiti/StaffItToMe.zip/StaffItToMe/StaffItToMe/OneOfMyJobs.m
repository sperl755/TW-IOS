//
//  OneOfMyJobs.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "OneOfMyJobs.h"


@implementation OneOfMyJobs

- (id)initWithFrame:(CGRect)frame andStatus:(int)status title:(NSString*)title startTime:(NSString*)start_time duration:(NSString*)duration rate:(NSString*)rate checkedInOrOut:(NSString*)checked_in_or_out timeClock:(NSString*)time_clock notes:(NSString*)notes
{
    self = [super initWithFrame:frame];
    if (self) {
        NSMutableString *job_info_string = [[NSMutableString alloc] initWithString:title];
        [job_info_string appendString:@", "];
        [job_info_string appendString:start_time];
        [job_info_string appendString:@", "];
        [job_info_string appendString:duration];
        [job_info_string appendString:@", "];
        [job_info_string appendString:rate];
        job_info = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, 300, 40)];
        job_info.text = job_info_string;
        [self addSubview:job_info];
		
		//setup job active billing label
        job_active_billing = [[UILabel alloc] initWithFrame:CGRectMake(5, job_info.frame.origin.y + job_info.frame.size.height, 300, 40)];
		job_active_billing.center = CGPointMake((int)320/2, job_active_billing.center.y);
		job_active_billing.text = @"Job Active Billing";
		[self addSubview:job_active_billing];
		
		//Setup the active history billing.
		active_bill_view = [[JobBillingHistoryView alloc] initWithFrame:CGRectMake(5, job_active_billing.frame.origin.y + job_active_billing.frame.size.height, 320, 50) andDate:@"Current Date" statusNotes:@"Chocolate milk is pretty much the best kindn of milk in the worl dand i wish i could drink it:)" time:@":30"];
		[self addSubview:active_bill_view];
		
		//Create check in out button
		check_in_out_btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
		check_in_out_btn.frame = CGRectMake(120, active_bill_view.frame.origin.y + active_bill_view.frame.size.height, 100, 50);
		[check_in_out_btn setTitle:@"Checked In/Out" forState:UIControlStateNormal];
		[self addSubview:check_in_out_btn];
		
		//Create Job histories
		all_jobs_history = [[AllJobBillingHistories alloc] initWithFrame:CGRectMake(5, check_in_out_btn.frame.origin.y + check_in_out_btn.frame.size.height, 310, 200)];
		[self insertSubview:all_jobs_history atIndex:0];
		
		//setup total time billed label
        total_time_billed = [[UILabel alloc] initWithFrame:CGRectMake(5, all_jobs_history.frame.origin.y + all_jobs_history.frame.size.height, 240, 40)];
		total_time_billed.center = CGPointMake((int)320/2, total_time_billed.center.y);
		total_time_billed.text = @"Total Time Billed";
		[self addSubview:total_time_billed];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void)dealloc
{
	[job_info release];
	[job_active_billing release];
	[active_bill_view release];
    [super dealloc];
}

@end

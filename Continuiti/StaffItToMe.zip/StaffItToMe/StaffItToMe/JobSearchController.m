//
//  JobSearchController.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "JobSearchController.h"
#import "StaffItToMeAppDelegate.h"


@implementation JobSearchController
-(id)init
{
    if ((self = [super init]))
    {
        gmap_menu = [[GMapMenuController alloc] init];
        gmap_menu.title = @"Jobs";
        navigation_controller = [[UINavigationController alloc] initWithRootViewController:gmap_menu];
        navigation_controller.delegate = self;
        [self.view addSubview:navigation_controller.view];
    }
    return self;
}
//Called by discussion screen to put a done keyboard button on the top for dimissing keyboard.
-(void)displayKeyboardDoneButton
{
    //Add keyboard done button for typing their message.
    UIBarButtonItem *done_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:job_discussion_screen action:@selector(removeKeyboard)];
    navigation_controller.navigationBar.topItem.rightBarButtonItem = done_button;
    [done_button release];
}
-(void)hideKeyboardDoneButton
{
    navigation_controller.navigationBar.topItem.rightBarButtonItem = nil;
}
-(void)displayApplyKeyboardDoneButton
{
    //Add keyboard done button for typing their message.
    UIBarButtonItem *done_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:job_apply_screen action:@selector(removeKeyboard)];
    navigation_controller.navigationBar.topItem.rightBarButtonItem = done_button;
    [done_button release];
}
-(void)hideApplyKeyboardDoneButton
{
    navigation_controller.navigationBar.topItem.rightBarButtonItem = nil;
}
-(void)jumpToJobDetail
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    job_detail_screen = [[JobDetailScreen alloc] init];
    [navigation_controller pushViewController:job_detail_screen animated:YES];
    StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
    job_detail_screen.title = [[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] title];
}
-(void)jumpToJobApply
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    job_apply_screen = [[JobApplyScreen alloc] init];
    job_apply_screen.delegate = self;
    [navigation_controller pushViewController:job_apply_screen animated:YES];
	StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
    job_apply_screen.title = [[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] title];
}

//Basically when the view controller is displayed add notification so that way it knows what buttons to use.
//Basically make NSNotification for the screens when they are displayed at any time.
-(void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (viewController == job_detail_screen) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(jumpToJobDiscussion) name:@"jumpToJobDiscussion" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(jumpToJobApply) name:@"jumpToJobApply" object:nil];
    }
    else if (viewController == gmap_menu) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(jumpToJobDetail) name:@"jumpToJobDetail" object:nil];
    }
    else if (viewController == job_discussion_screen) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(popController) name:@"MessageSent" object:nil];
    }
}
-(void)popController
{
    [navigation_controller popToRootViewControllerAnimated:YES];
}
/*
 Go to the job discussion screen after user clicks discuss in job description
 */
-(void)jumpToJobDiscussion
{
    //remove old notification about this object
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //Create screen for discussion
    job_discussion_screen = [[JobDiscussionScreen alloc] init];
    job_discussion_screen.delegate = self;
    
    
    //[navigation_controller.navigationItem setRightBarButtonItem:done_button];
    
    //Go To next Screen
    [navigation_controller pushViewController:job_discussion_screen animated:YES];
    job_discussion_screen.title = @"Discuss";
    
    
}
//Deallocate memory for this object
-(void)dealloc
{
    [navigation_controller release];
    [gmap_menu release];
    [super dealloc];
}
@end

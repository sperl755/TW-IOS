//
//  JobSearchController.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GMapMenuController.h"
#import "JobDetailScreen.h"
#import "JobDiscussionScreen.h"
#import "JobApplyScreen.h"

@interface JobSearchController : UIViewController <DiscussionScreenProtocol, UINavigationControllerDelegate, ApplyScreenProtocol>
{
    UINavigationController *navigation_controller;
    GMapMenuController *gmap_menu;
    JobDetailScreen *job_detail_screen;
    JobDiscussionScreen *job_discussion_screen;
    JobApplyScreen *job_apply_screen;
}

@end

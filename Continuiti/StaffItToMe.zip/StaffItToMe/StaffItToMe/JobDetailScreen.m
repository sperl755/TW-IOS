//
//  JobDetailScreen.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "JobDetailScreen.h"
#import "StaffItToMeAppDelegate.h"


@implementation JobDetailScreen
-(id)init
{
    if ((self = [super init]))
    {
        StaffItToMeAppDelegate *delegate = (StaffItToMeAppDelegate*)[[UIApplication sharedApplication] delegate];
        array_position = delegate.user_state_information.current_job_in_array;
        
        NSMutableString *job_details = [[NSMutableString alloc] initWithString:@"Start Time: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] task_start_time]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Start Date: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] task_start_date]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Description: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] job_description]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Created at: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] created_at]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Duration: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] job_duration]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Hour Per Week: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] hours_per_week]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Start Time: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] task_start_time]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Company: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] company]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Company Description: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] company_description]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Compensation: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] compensation]];
        [job_details appendString:@"\n"];
        [job_details appendString:@"Skills Needed: "];
        [job_details appendString:[[delegate.user_state_information.job_array objectAtIndex:delegate.user_state_information.current_job_in_array] skills]];
        [job_details appendString:@"\n"];
         
        //Display description of job
        description_txt = [[UITextView alloc] initWithFrame:CGRectMake(5, 15, 310, 250)];
        description_txt.text = job_details;
        [description_txt setEditable:NO];
        description_txt.font = [UIFont fontWithName:@"Times New Roman" size:18];
        [self.view addSubview:description_txt];
        
        apply_btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        apply_btn.frame = CGRectMake(5, 270, 120, 55);
        [apply_btn setTitle:@"Apply" forState:UIControlStateNormal];
        [apply_btn addTarget:self action:@selector(applyScreen) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:apply_btn];
        
        discuss_btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        discuss_btn.frame = CGRectMake(195, 270, 120, 55);
        [discuss_btn setTitle:@"Discuss" forState:UIControlStateNormal];
        [discuss_btn addTarget:self action:@selector(discussScreen) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:discuss_btn];
        
    }
    return self;
}
-(void)applyScreen
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"jumpToJobApply" object:nil];
}
-(void)discussScreen
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"jumpToJobDiscussion" object:nil];
}

@end

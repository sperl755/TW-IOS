//
//  AvailableJobsAnnotation.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AvailableJobsAnnotation.h"


@implementation AvailableJobsAnnotation
@synthesize coordinate=_coordinate, title=_title, subtitle=_subTitle, pin_id;

-(id)initWithTitle:(NSString*)theTitle subTitle:(NSString*)theSubTitle andCoordinate:(CLLocationCoordinate2D)theCoordinate andID:(NSString*)the_id;
{
    if ((self = [super init])) {
        _title = [theTitle copy];
        _subTitle = [theSubTitle copy];
        _coordinate = theCoordinate;
        pin_id = [the_id copy];
        
    }
    return self;
}
-(void)dealloc
{
    [_title release];
    [_subTitle release];
    [pin_id release];
    [super dealloc];
}
@end

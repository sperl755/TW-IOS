//
//  MyJob.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
/*
 This data model represents an Job that the user
 has applied for and is currently a part of.
 */

@interface MyJob : NSObject {
    
}
/*
 Information about the job.
 */
@property (nonatomic, assign) int status;
@property (nonatomic, assign) NSString *checked_in_out;
@property (nonatomic, assign) NSString *title;
@property (nonatomic, assign) NSString *start_time;
@property (nonatomic, assign) NSString *duration;
@property (nonatomic, assign) NSString *rate;
@property (nonatomic, assign) NSString *time_clock;
@property (nonatomic, assign) NSString *notes;
//An array of job billing history objects.
@property (nonatomic, assign) NSMutableArray *job_history;

@end

//
//  USERINFORMATIONANDAPPSTATE.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "USERINFORMATIONANDAPPSTATE.h"
#import "ASIFormDataRequest.h"
#import "StaffItToMeAppDelegate.h"


@implementation USERINFORMATIONANDAPPSTATE
@synthesize currentTabBar;
@synthesize userName;
@synthesize sessionKey;
@synthesize job_array;
@synthesize current_job_in_array;
@synthesize my_jobs;


-(id)init
{
    if ((self = [super init]))
    {
        currentTabBar = [[NSString alloc] init];
        userName = [[NSString alloc] init];
        sessionKey = [[NSString alloc] init];
        job_array = [[NSMutableArray alloc] initWithCapacity:20];
        my_jobs = [[NSMutableArray alloc] initWithCapacity:20];
    }
    return self;
}

-(void)populateJobArrayWithJSONString:(NSString *)the_string
{
	
	printf("\nThis is the string from servers: %s\n", [the_string UTF8String]);
   /* if (the_string.length < 5) {
		UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Maybe Search Again?" message:@"Unfortunately we could not find any jobs for you. Go ahead and change your keywords and try again!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[message show];
		[message release];
        return;
    }*/
	NSString *filePath = [[NSBundle mainBundle] pathForResource:@"JSONFILE" ofType:@"json"];
	NSString *fileContent = [[NSString alloc] initWithContentsOfFile:filePath]; 
	
	//NSString *chocolate = [the_string substringWithRange:NSMakeRange(1,the_string.length -2)];
    //Create a dicionary based off of the JSON String.
    NSDictionary *data_dict = [fileContent JSONValue];
    //Create an enumerator for getting the different jobs
    NSEnumerator *enumerator = [data_dict keyEnumerator];
    NSString *currentPosition;
    while ((currentPosition = [enumerator nextObject]) != nil)
    {
        SmallJobs *temp_small_job = [[SmallJobs alloc] init];
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"title"] == [NSNull null])
        {
            temp_small_job.title = @"NA";
        } else {
            temp_small_job.title = [[[data_dict objectForKey:currentPosition] objectForKey:@"title"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"skills"] == [NSNull null]) {
            temp_small_job.skills = @"NA";
        } else {
            temp_small_job.skills = [[[data_dict objectForKey:currentPosition] objectForKey:@"skills"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"id"] == [NSNull null]) {
            temp_small_job.job_id = @"NA";
        } else {
            temp_small_job.job_id = [[NSString stringWithFormat:@"%d",[[data_dict objectForKey:currentPosition] objectForKey:@"id"]] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"description"] == [NSNull null]) {
            temp_small_job.job_description = @"NA";
        } else {
            temp_small_job.job_description = [[[data_dict objectForKey:currentPosition] objectForKey:@"description"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"user_id"] == [NSNull null]) {
            temp_small_job.user_id = @"NA";
        } else {
            temp_small_job.user_id = [[[data_dict objectForKey:currentPosition] objectForKey:@"user_id"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"created_at"] == [NSNull null]) {
            temp_small_job.created_at = @"NA";
        } else {
            temp_small_job.created_at = [[[data_dict objectForKey:currentPosition] objectForKey:@"created_at"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"duration"] == [NSNull null]) {
            temp_small_job.job_duration = @"NA";
        } else {
            temp_small_job.job_duration = [[[data_dict objectForKey:currentPosition] objectForKey:@"duration"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"hours_per_week"] == [NSNull null]) {
            temp_small_job.hours_per_week = @"NA";
        } else {
            temp_small_job.hours_per_week = [[[data_dict objectForKey:currentPosition] objectForKey:@"hours_per_week"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"task_start_date"] == [NSNull null]) {
            temp_small_job.task_start_date = @"NA";
        } else {
            temp_small_job.task_start_date = [[[data_dict objectForKey:currentPosition] objectForKey:@"task_start_date"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"task_start_time"] == [NSNull null]) {
            temp_small_job.task_start_time = @"NA";
        } else {
            temp_small_job.task_start_time = [[[data_dict objectForKey:currentPosition] objectForKey:@"task_start_time"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"company"] == [NSNull null]) {
            temp_small_job.company = @"NA";
        } else {
            temp_small_job.company = [[[data_dict objectForKey:currentPosition] objectForKey:@"company"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"company_description"] == [NSNull null]) {
            temp_small_job.company_description = @"NA";
        } else {
            temp_small_job.company_description = [[[data_dict objectForKey:currentPosition] objectForKey:@"company_description"] retain];
        }
        NSLog(@"\nThis is the company)descriontpiong: %@\n", [[[data_dict objectForKey:currentPosition] objectForKey:@"company_description"]class]);
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"compensation"]  == [NSNull null]) {
            temp_small_job.compensation = @"NA";
        } else {
            temp_small_job.compensation = [[[data_dict objectForKey:currentPosition] objectForKey:@"compensation"] retain];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"latitude"] == [NSNull null]) {
            temp_small_job.latitude = 0;
        } else {
            temp_small_job.latitude = [[[data_dict objectForKey:currentPosition] objectForKey:@"latitude"] doubleValue];
        }
        if ([[data_dict objectForKey:currentPosition] objectForKey:@"longitude"] == [NSNull null]) {
            temp_small_job.longitude = 0;
        } else {
            temp_small_job.longitude = [[[data_dict objectForKey:currentPosition] objectForKey:@"longitude"] doubleValue];
        }
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"title"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"skills"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"id"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"description"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"user_id"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"created_at"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"duration"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"hours_per_week"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"task_start_date"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"task_start_time"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"company"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"company_description"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"compensation"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"latitude"]);
        NSLog(@"%@", [[data_dict objectForKey:currentPosition] objectForKey:@"longitude"]);
        [job_array addObject:temp_small_job];
        [temp_small_job release];
    }
	printf("Job array count: %d", [job_array count]);
}
-(void)populateMyJobArray
{
    /*
	NSString *chocolate = [the_string substringWithRange:NSMakeRange(1,the_string.length -2)];
    //Create a dicionary based off of the JSON String.
    NSDictionary *data_dict = [chocolate JSONValue];
    //Create an enumerator for getting the different jobs
    NSEnumerator *enumerator = [data_dict keyEnumerator];
    NSString *currentPosition;
    while ((currentPosition = [enumerator nextObject]) != nil)
    {
		MyJob *temp_my_job = [[MyJob alloc] init];
		temp_my_job.title = [[[data_dict objectForKey:currentPosition] objectForKey:@"title"] retain];
		temp_my_job.status = [[[data_dict objectForKey:currentPosition] objectForKey:@"status"] retain];
		temp_my_job.checked_in_out = [[[data_dict objectForKey:currentPosition] objectForKey:@"checked_in_out"] retain];
		temp_my_job.start_time = [[[data_dict objectForKey:currentPosition] objectForKey:@"start_time"] retain];
		temp_my_job.duration = [[[data_dict objectForKey:currentPosition] objectForKey:@"duration"] retain];
		temp_my_job.rate = [[[data_dict objectForKey:currentPosition] objectForKey:@"rate"] retain];
		temp_my_job.time_clock = [[[data_dict objectForKey:currentPosition] objectForKey:@"time_clock"] retain];
		temp_my_job.notes = [[[data_dict objectForKey:currentPosition] objectForKey:@"notes"] retain];
		
        
        [my_jobs addObject:temp_my_job];
        [temp_my_job release];
    }
	printf("%d", [my_jobs count]);*/
}
@end

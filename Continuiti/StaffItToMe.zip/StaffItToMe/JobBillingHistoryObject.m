//
//  JobBillingHistoryObject.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "JobBillingHistoryObject.h"


@implementation JobBillingHistoryObject
@synthesize date;
@synthesize status_notes;
@synthesize time;
@end

//
//  TaskLocation.m
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/27/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TaskLocation.h"


@implementation TaskLocation
@synthesize address_one;
@synthesize address_two;
@synthesize address_name;
@synthesize city;
@synthesize state;
@synthesize country;
@synthesize phone;
@synthesize contact_name;
@synthesize zipcode;

@end

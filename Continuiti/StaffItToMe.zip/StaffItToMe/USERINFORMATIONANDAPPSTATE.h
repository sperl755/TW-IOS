//
//  USERINFORMATIONANDAPPSTATE.h
//  StaffItToMe
//
//  Created by Anthony Sierra on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SmallJobs.h"
#import "MyJob.h"
/*
 This class is everything about the user and is used only
 after login. IT represents the jobs that the user has
 the ones they can get and more.
 */
@interface USERINFORMATIONANDAPPSTATE : NSObject {
    
}
-(void)populateMyJobArray;
-(void)populateJobArrayWithJSONString:(NSString *)the_string;
@property (nonatomic, assign) NSString *currentTabBar;
@property (nonatomic, assign) NSString *userName;
@property (nonatomic, assign) NSString *sessionKey;
//Array of SmallJobs objects which is all the small
//jobs that are currently available to them.
//This is used on the job search tab.
@property (nonatomic, assign) NSMutableArray *job_array;
@property (nonatomic, assign) NSUInteger current_job_in_array;
//Array of MyJob objects which are the jobs that the user
//currently has.
//This is used on the my jobs tab.
@property (nonatomic, assign) NSMutableArray *my_jobs;
@end
